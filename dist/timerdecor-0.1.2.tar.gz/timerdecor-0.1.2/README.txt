Allows the measurement of time required for python functions.
Uses the @timer decorator.